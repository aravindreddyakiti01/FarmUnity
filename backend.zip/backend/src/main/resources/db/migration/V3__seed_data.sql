-- FarmUnity Seed Data Migration V3 (BCrypt hash for 'password123' is $2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a)

-- Seed Farmers
INSERT INTO farmers (id, name, phone, email, password_hash, latitude, longitude, address, trust_tier, reliability_score, is_active)
VALUES
    (1, 'Ramesh Kumar', '9876543210', 'ramesh@farmunity.in', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', 12.9716, 77.5946, 'Village Hoskote, Bengaluru Rural', 'VERIFIED', 88.50, TRUE),
    (2, 'Suresh Gowda', '9876543211', 'suresh@farmunity.in', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', 12.9249, 77.6321, 'Village Nelamangala, Bengaluru Rural', 'NEW', 65.00, TRUE),
    (3, 'Venkat Rao', '9876543212', 'venkat@farmunity.in', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', 12.8500, 77.5500, 'Village Devanahalli, Bengaluru Rural', 'ESTABLISHED', 94.00, TRUE)
ON CONFLICT (phone) DO NOTHING;

-- Seed Buyers
INSERT INTO buyers (id, name, phone, email, password_hash, org_type, latitude, longitude, address, trust_tier, reliability_score, commitment_deposit_balance, is_active)
VALUES
    (1, 'Bangalore Central Hostel Network', '9876543220', 'procurement@bchostels.org', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', 'HOSTEL', 12.9352, 77.6245, 'Koramangala 4th Block, Bengaluru', 'VERIFIED', 92.00, 50000.0000, TRUE)
ON CONFLICT (phone) DO NOTHING;

-- Seed Coordinator
INSERT INTO coordinators (id, name, phone, email, password_hash, region, is_active)
VALUES
    (1, 'Anand Sharma (Coordinator)', '9876543230', 'anand@farmunity.org', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', 'Bengaluru Rural & Urban', TRUE)
ON CONFLICT (phone) DO NOTHING;

-- Seed Processor (Miller)
INSERT INTO processors (id, name, phone, address, latitude, longitude, capacity, fee_per_kg, wallet_balance, is_active)
VALUES
    (1, 'Sri Lakshmi Modern Rice Mill', '9876543240', 'Industrial Area, Whitefield, Bengaluru', 12.9698, 77.7500, 5000.0000, 1.5000, 10000.0000, TRUE)
ON CONFLICT (id) DO NOTHING;

-- Reset identity sequence counters
SELECT setval('farmers_id_seq', (SELECT MAX(id) FROM farmers));
SELECT setval('buyers_id_seq', (SELECT MAX(id) FROM buyers));
SELECT setval('coordinators_id_seq', (SELECT MAX(id) FROM coordinators));
SELECT setval('processors_id_seq', (SELECT MAX(id) FROM processors));
