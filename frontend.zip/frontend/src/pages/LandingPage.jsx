import React from 'react';
import { Link } from 'react-router-dom';
import { Sprout, Building2, UserCheck, ShieldCheck, ArrowRight, Layers, FileCheck2, Scale } from 'lucide-react';

export const LandingPage = () => {
  return (
    <div className="space-y-16 py-6">
      {/* Hero Section */}
      <div className="text-center max-w-4xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-green-100 text-green-800 border border-green-300">
          <ShieldCheck className="w-4 h-4 text-green-600" /> Smart India Hackathon · Problem Statement 33
        </div>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-900 tracking-tight leading-tight">
          Turn Many Small Farmers Into One <span className="text-green-600">Reliable Bulk Supplier</span>
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
          FarmUnity dynamically clusters smallholder farmers into cooperative batches, matches them directly against verified institutional demand, coordinates milling, and settles transparently against verified quantities.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <Link
            to="/register"
            className="px-6 py-3.5 text-base font-bold text-white bg-green-600 hover:bg-green-700 rounded-xl shadow-md transition flex items-center gap-2"
          >
            Get Started <ArrowRight className="w-5 h-5" />
          </Link>
          <Link
            to="/login"
            className="px-6 py-3.5 text-base font-bold text-gray-700 bg-white hover:bg-gray-100 rounded-xl border border-gray-200 shadow-sm transition"
          >
            Sign In with Demo Credentials
          </Link>
        </div>
      </div>

      {/* Demo Credentials Quick Box */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 max-w-4xl mx-auto shadow-sm">
        <h3 className="text-sm font-bold text-emerald-900 uppercase tracking-wider mb-3">Pre-configured Demo Accounts (Password: password123)</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="bg-white p-3 rounded-lg border border-emerald-100">
            <span className="font-bold text-gray-800 block">Farmer (Ramesh Kumar)</span>
            <span className="text-gray-500 font-mono">9876543210</span>
            <span className="text-emerald-700 block mt-1 font-semibold">500kg Paddy · 13.2% Moisture (Pass)</span>
          </div>
          <div className="bg-white p-3 rounded-lg border border-emerald-100">
            <span className="font-bold text-gray-800 block">Institutional Buyer (Hostel)</span>
            <span className="text-gray-500 font-mono">9876543220</span>
            <span className="text-blue-700 block mt-1 font-semibold">Bangalore Central Hostel · 600kg Requirement</span>
          </div>
          <div className="bg-white p-3 rounded-lg border border-emerald-100">
            <span className="font-bold text-gray-800 block">Quality Coordinator (Anand)</span>
            <span className="text-gray-500 font-mono">9876543230</span>
            <span className="text-purple-700 block mt-1 font-semibold">Inspection · Clustering · Settlement</span>
          </div>
        </div>
      </div>

      {/* Three Pillar Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition">
          <div className="p-3 bg-green-100 text-green-700 rounded-xl w-fit mb-5">
            <Sprout className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-bold text-gray-900">For Small Farmers</h3>
          <p className="text-sm text-gray-600 mt-2 leading-relaxed">
            Eliminate commission agents. Set protected floor prices, aggregate with nearby farmers to fulfill bulk demand, and receive transparent bank settlement based on verified weights.
          </p>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition">
          <div className="p-3 bg-blue-100 text-blue-700 rounded-xl w-fit mb-5">
            <Building2 className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-bold text-gray-900">For Bulk Institutions</h3>
          <p className="text-sm text-gray-600 mt-2 leading-relaxed">
            Hospitals, hostels, hotels, and canteens get direct, batch-verified, traceable staple supply with quality checks and protected simulated escrow commitments.
          </p>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition">
          <div className="p-3 bg-purple-100 text-purple-700 rounded-xl w-fit mb-5">
            <UserCheck className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-bold text-gray-900">Deterministic Verification</h3>
          <p className="text-sm text-gray-600 mt-2 leading-relaxed">
            Hard moisture-band checks (12–14% for paddy), explainable greedy clustering, versioned multi-party agreements, and tamper-evident SHA-256 integrity logs.
          </p>
        </div>
      </div>
    </div>
  );
};
