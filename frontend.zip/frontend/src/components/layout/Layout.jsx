import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';
import { OfflineIndicator } from '../offline/OfflineIndicator';

export const Layout = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <OfflineIndicator />
      <Navbar />
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>
      <footer className="bg-white border-t border-gray-200 py-6 text-center text-xs text-gray-400">
        <p>FarmUnity — Demand-Driven Agricultural Fulfilment Network · Smart India Hackathon PS33</p>
        <p className="mt-1">AI recommends · Humans verify & approve · Optimization coordinates · Payment layer protects commitments · Audit layer preserves integrity</p>
      </footer>
    </div>
  );
};
