import React from 'react';
import { AlertTriangle } from 'lucide-react';

export const SimulatedLedgerBanner = () => {
  return (
    <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-6 rounded-r-md shadow-sm">
      <div className="flex items-center">
        <AlertTriangle className="h-5 w-5 text-amber-500 mr-3 flex-shrink-0" />
        <div className="text-sm text-amber-800">
          <span className="font-semibold uppercase tracking-wide text-xs bg-amber-200 text-amber-900 px-2 py-0.5 rounded mr-2">
            Hackathon Demo
          </span>
          This is a <strong>simulated commitment/ledger flow</strong> for Smart India Hackathon (Problem Statement 33) — not an actual custodial bank or financial payment gateway. All amounts represent internal simulated commitments.
        </div>
      </div>
    </div>
  );
};
